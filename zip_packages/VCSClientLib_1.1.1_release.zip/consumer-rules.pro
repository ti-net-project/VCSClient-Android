-keep class com.tinet.vcslib.** {*;}
-dontwarn  com.tinet.vcslib.**
-keep class io.agora.**{*;}
-keep class kotlin.Metadata
-dontwarn io.agora.**
-dontwarn com.google.devtools.build.android.desugar.runtime.ThrowableExtension

# Keep Retrofit
-keep class retrofit.** { *; }
-keepclasseswithmembers class * {
    @retrofit.** *;
}
-keepclassmembers class * {
    @retrofit.** *;
}

-keepclassmembers class **.R$* {
  public static <fields>;
}
